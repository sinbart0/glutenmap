tinyMCE.addI18n('bg.modxlink',{
    link_desc:"Insert/edit link"
});