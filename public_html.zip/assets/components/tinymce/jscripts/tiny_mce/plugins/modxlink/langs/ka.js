tinyMCE.addI18n('ka.modxlink',{
    link_desc:"Insert/edit link"
});